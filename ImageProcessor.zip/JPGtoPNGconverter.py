import os
from PIL import Image

ImageFolder = "./NameOfTheFolderWithThePictures/"
OutputFolder = "./NewFolderToExportThePicture/"

if not os.path.exists(OutputFolder):
    os.makedirs(OutputFolder)

for filename in os.listdir(ImageFolder):
    img = Image.open(f'{ImageFolder}{filename}')
    CleanName = os.path.splitext(filename)[0]
    img.save(f'{OutputFolder}{CleanName}.png', 'png')
    print("all done")
