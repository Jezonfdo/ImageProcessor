from PIL import Image, ImageFilter

img = Image.open('./Pokedex/Astro/Astro.jpg')
img.thumbnail((400, 400))

img.save("Astro Compressed.jpg", 'png')